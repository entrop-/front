/**
 * Created by entrop on 04/10/15.
 */


//angular
var app = angular.module("bls",[]);
